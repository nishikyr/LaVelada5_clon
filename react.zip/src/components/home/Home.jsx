
const Home=()=>{
    return(
        
            <h1>HOME WORKS!</h1>
        
    )
}

export default Home;